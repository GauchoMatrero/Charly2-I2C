/* 
* usitwi.h
*
* Created: 06/06/2017 21:42:33
* Author: carlos
*/


#ifndef __USITWI_H__
#define __USITWI_H__


class usitwi
{
//variables
public:
protected:
private:

//functions
public:
	usitwi();
	~usitwi();
protected:
private:
	usitwi( const usitwi &c );
	usitwi& operator=( const usitwi &c );

}; //usitwi

#endif //__USITWI_H__
