/* 
* usitwi.cpp
*
* Created: 06/06/2017 21:42:31
* Author: carlos
*/


#include "usitwi.h"

// default constructor
usitwi::usitwi()
{
} //usitwi

// default destructor
usitwi::~usitwi()
{
} //~usitwi
